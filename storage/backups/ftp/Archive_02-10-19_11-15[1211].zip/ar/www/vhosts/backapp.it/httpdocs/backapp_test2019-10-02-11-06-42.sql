DROP TABLE vvvvv;

CREATE TABLE `vvvvv` (
  `id` int(22) NOT NULL AUTO_INCREMENT,
  `asdasd` varchar(222) NOT NULL,
  `fsddvsd` int(222) NOT NULL,
  `cvxwe` int(222) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




